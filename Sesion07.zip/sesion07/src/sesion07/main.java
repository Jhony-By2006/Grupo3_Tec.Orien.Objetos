/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sesion07;

/**
 *
 * @author bryam
 */
public class main {
    public static void main(String[] args) 
    {
        
        Mamifero[] mamiferos = new Mamifero[6];

        // Crear instancias de cada clase concreta 
        Mamifero leon = new Leon("Sabana Africana", 1.2, 2.1, 190.0, "Panthera leo", 7.5, 80, 15, 114.0);
        Mamifero tigre = new Tigre("Selvas de la India", 1.1, 3.0, 220.0, "Panthera tigris", 8.0, 65, "Tigre de Bengala");
        Mamifero guepardo = new Guepardo("Sabana Africana", 0.9, 1.5, 60.0, "Acinonyx jubatus", 6.5, 110);
        Mamifero lobo = new Lobo("Bosques de Norteamérica", 0.8, 1.6, 50.0, "Canis lupus", "Gris", 4.5, 6, "Lobo Gris");
        Mamifero perro = new Perro("Llanuras Africanas", 0.7, 1.2, 25.0, "Lycaon pictus", "Moteado", 4.0, 317);
        Mamifero loboIberico = new Lobo("Península Ibérica", 0.75, 1.4, 40.0, "Canis lupus signatus", "Pardo", 4.2, 5, "Lobo Ibérico");

        // Asignar los objetos al arreglo 
        mamiferos[0] = leon;
        mamiferos[1] = tigre;
        mamiferos[2] = guepardo;
        mamiferos[3] = lobo;
        mamiferos[4] = perro;
        mamiferos[5] = loboIberico;

        // Recorrer el arreglo y mostrar los datos 
        for (Mamifero animal : mamiferos) 
        {
            System.out.println("----------------------------------------------------");
            System.out.println("Nombre Cientifico: " + animal.getNombreCientifico());
            System.out.println("Habitat: " + animal.getHabitat());
            System.out.println("Dimensiones (alto, largo, peso): " + animal.getAltura() + "m, " + animal.getLargo() + "m, " + animal.getPeso() + "kg");
            
            // Imprimir detalles específicos del tipo
            if (animal instanceof Felino felino) 
            {
                System.out.println("Velocidad: " + felino.getVelocidad() + " km/h");
                System.out.println("Tamaño Garras: " + felino.getTamanoGarras() + " cm");
            }
            if (animal instanceof Canino canino) 
            {
                System.out.println("Color: " + canino.getColor());
                System.out.println("Tamaño Colmillos: " + canino.getTamañoColmillos() + " cm");
            }
            if (animal instanceof Leon leon1) 
            {
                System.out.println("Manada: " + leon1.getNumeroManada() + " leones");
            }
            // ... (se pueden agregar más instanceof para otros tipos si se desea)

            System.out.println("\n--- Comportamientos ---");
            System.out.println("Comer: " + animal.comer());
            System.out.println("Dormir: " + animal.dormir());
            System.out.println("Correr: " + animal.correr());
            System.out.println("Comunicarse: " + animal.comunicarse());
            System.out.println("----------------------------------------------------\n");
        }
    }
}






