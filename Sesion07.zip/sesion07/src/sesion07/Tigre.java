/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sesion07;

/**
 *
 * @author bryam
 */
public class Tigre extends Felino {
    private String especieTigre;

    public Tigre(String habitat, double altura, double largo, double peso, String nombreCientifico, double tamanoGarras, int velocidad, String especieTigre) {
        super(habitat, altura, largo, peso, nombreCientifico, tamanoGarras, velocidad);
        this.especieTigre = especieTigre;
    }

    public String getEspecieTigre() {
        return especieTigre;
    }

    @Override
    public String comer() {
        return "El Tigre de " + getEspecieTigre() + " caza sigilosamente en la selva de " + getHabitat() + ".";
    }

    @Override
    public String dormir() {
        return "El Tigre (" + getNombreCientifico() + ") descansa entre la densa vegetación.";
    }

    @Override
    public String correr() {
        return "Con una velocidad de " + getVelocidad() + " km/h, el Tigre persigue a su presa.";
    }

    @Override
    public String comunicarse() {
        return "El Tigre se comunica con rugidos graves y marcas de garras de " + getTamanoGarras() + " cm.";
    }
}
