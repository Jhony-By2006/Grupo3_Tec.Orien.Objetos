/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sesion07;

/**
 *
 * @author bryam
 */
public class Guepardo extends Felino {
    public Guepardo(String habitat, double altura, double largo, double peso, String nombreCientifico, double tamanoGarras, int velocidad) {
        super(habitat, altura, largo, peso, nombreCientifico, tamanoGarras, velocidad);
    }

    @Override
    public String comer() {
        return "El Guepardo se alimenta de sus presas después de una corta y veloz persecución en " + getHabitat() + ".";
    }

    @Override
    public String dormir() {
        return "El Guepardo (" + getNombreCientifico() + ") duerme la siesta en las altas hierbas de la sabana.";
    }

    @Override
    public String correr() {
        return "El Guepardo es el felino mas rápido, alcanzando velocidades de hasta " + getVelocidad() + " km/h.";
    }

    @Override
    public String comunicarse() {
        return "El Guepardo emite sonidos agudos y ronroneos para comunicarse.";
    }
}
