/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sesion07;

/**
 *
 * @author bryam
 */
public class Perro extends Canino {
    private int fuerzaMordida; // en PSI

    public Perro(String habitat, double altura, double largo, double peso, String nombreCientifico, String color, double tamanoColmillos, int fuerzaMordida) {
        super(habitat, altura, largo, peso, nombreCientifico, color, tamanoColmillos);
        this.fuerzaMordida = fuerzaMordida;
    }

    public int getFuerzaMordida() {
        return fuerzaMordida;
    }

    @Override
    public String comer() {
        return "El perro salvaje africano (" + getNombreCientifico() + ") come en grupo con una gran eficiencia.";
    }

    @Override
    public String dormir() {
        return "El perro salvaje de color " + getColor() + " duerme en madrigueras durante el día.";
    }

    @Override
    public String correr() {
        return "Este canino corre por las llanuras de " + getHabitat() + " para agotar a sus presas.";
    }

    @Override
    public String comunicarse() {
        return "Se comunica con ladridos y chillidos agudos, y tiene una mordida de " + getFuerzaMordida() + " PSI.";
    }
}
