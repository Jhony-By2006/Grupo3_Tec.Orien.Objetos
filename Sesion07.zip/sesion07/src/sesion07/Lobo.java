/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sesion07;

/**
 *
 * @author bryam
 */
public class Lobo extends Canino {
    private int numeroCamada;
    private String especieLobo;

    public Lobo(String habitat, double altura, double largo, double peso, String nombreCientifico, String color, double tamanoColmillos, int numeroCamada, String especieLobo) {
        super(habitat, altura, largo, peso, nombreCientifico, color, tamanoColmillos);
        this.numeroCamada = numeroCamada;
        this.especieLobo = especieLobo;
    }

    public int getNumeroCamada() {
        return numeroCamada;
    }

    public String getEspecieLobo() {
        return especieLobo;
    }

    @Override
    public String comer() {
        return "El Lobo " + getEspecieLobo() + " caza en manadas en los bosques de " + getHabitat() + ".";
    }

    @Override
    public String dormir() {
        return "El Lobo " + getColor() + " duerme en las cavernas de " + getHabitat() + "."; // 
    }

    @Override
    public String correr() {
        return "Un Lobo de la especie " + getEspecieLobo() + " corre largas distancias en busca de alimento.";
    }

    @Override
    public String comunicarse() {
        return "El Lobo aulla para comunicarse con su camada de " + getNumeroCamada() + " miembros.";
    }
}