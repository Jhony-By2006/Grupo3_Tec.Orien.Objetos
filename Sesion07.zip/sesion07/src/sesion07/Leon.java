/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sesion07;

/**
 *
 * @author bryam
 */
public class Leon extends Felino {
    private int numeroManada;
    private double potenciaRugidoDecibel;

    public Leon(String habitat, double altura, double largo, double peso, String nombreCientifico, double tamanoGarras, int velocidad, int numeroManada, double potenciaRugidoDecibel) {
        super(habitat, altura, largo, peso, nombreCientifico, tamanoGarras, velocidad);
        this.numeroManada = numeroManada;
        this.potenciaRugidoDecibel = potenciaRugidoDecibel;
    }

    public int getNumeroManada() {
        return numeroManada;
    }

    public double getPotenciaRugidoDecibel() {
        return potenciaRugidoDecibel;
    }

    @Override
    public String comer() {
        return "El Leon " + getNombreCientifico() + " caza junto a su grupo de " + getNumeroManada() + " individuos en las llanuras de " + getHabitat() + "."; // 
    }

    @Override
    public String dormir() {
        return "El Leon duerme en la sabana africana.";
    }

    @Override
    public String correr() {
        return "El Leon corre a " + getVelocidad() + " km/h para proteger a su manada.";
    }

    @Override
    public String comunicarse() {
        return "El Leon ruge con una potencia de " + getPotenciaRugidoDecibel() + " decibeles para comunicarse.";
    }
}
