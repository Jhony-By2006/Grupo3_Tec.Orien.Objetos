/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package caseestudys11;

/**
 *
 * @author Usuario
 */
public class Tema {
    private String titulo;
    private String contenido;

    public Tema(String titulo, String contenido) {
        this.titulo = titulo;
        this.contenido = contenido;
    }

    public void mostrarTema() {
        System.out.println("  Tema: " + titulo);
        System.out.println("    Contenido: " + contenido);
    }
}
