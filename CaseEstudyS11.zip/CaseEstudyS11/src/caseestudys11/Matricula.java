/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package caseestudys11;

/**
 *
 * @author Usuario
 */
public class Matricula {
    
    private Asignatura asignatura;
    private int ciclo;
    private int semestre;
    
    public Matricula(Asignatura asignatura, int ciclo, int semestre) {
        this.asignatura = asignatura;
        this.ciclo = ciclo;
        this.semestre = semestre;
    }

    public void mostrarMatricula() {
        System.out.println("  Asignatura: " + asignatura.getClass());
        System.out.println("  Ciclo: " + ciclo + " | Semestre: " + semestre);
    }
}
