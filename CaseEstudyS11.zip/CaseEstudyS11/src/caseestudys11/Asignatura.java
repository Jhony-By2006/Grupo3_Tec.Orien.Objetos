/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package caseestudys11;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Usuario
 */
public class Asignatura {
    private String codigo;
    private String nombre;
    private List<Tema> temas;

    public Asignatura(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.temas = new ArrayList<>();
    }
    
    public void agregarTema(Tema tema) {
        temas.add(tema);
    }

    public String getNombre() {
        return nombre;
    }

    public void mostrarAsignatura() {
        System.out.println("Asignatura: " + nombre + " (" + codigo + ")");
        System.out.println("Temas:");
        for (Tema t : temas) {
            t.mostrarTema();
        }
    }
}
