/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caseestudys11;

/**
 *
 * @author Usuario
 */
public class CaseEstudyS11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // Crear grupo común
        Grupo grupo1 = new Grupo(1, "Grupo Alfa");

        // Crear asignatura y temas
        Asignatura asignatura1 = new Asignatura("INF101", "Programación Básica");
        asignatura1.agregarTema(new Tema("Variables", "Tipos de datos y declaración"));
        asignatura1.agregarTema(new Tema("Condicionales", "Uso de if, else, switch"));
        asignatura1.agregarTema(new Tema("Bucles", "for, while y do-while"));

        // Crear estudiantes
        Estudiante est1 = new Estudiante("Gomez", "Lopez", "Ana María", "12345678", grupo1);
        Estudiante est2 = new Estudiante("Perez", "Vera", "Luis Carlos", "87654321", grupo1);

        // Matricular a ambos en la misma asignatura
        Matricula mat1 = new Matricula(asignatura1, 1, 2025);
        Matricula mat2 = new Matricula(asignatura1, 1, 2025);

        est1.agregarMatricula(mat1);
        est2.agregarMatricula(mat2);

        // Mostrar información completa
        System.out.println("========= DATOS DE ESTUDIANTE 1 =========");
        est1.mostrarEstudiante();
        System.out.println("\n========= DATOS DE ESTUDIANTE 2 =========");
        est2.mostrarEstudiante();
        System.out.println("\n========= DETALLE DE LA ASIGNATURA =========");
        asignatura1.mostrarAsignatura();
    }
    
}
