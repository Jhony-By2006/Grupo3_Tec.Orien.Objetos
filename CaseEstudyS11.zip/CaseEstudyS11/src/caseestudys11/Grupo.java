/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package caseestudys11;

/**
 *
 * @author Usuario
 */
public class Grupo {
    private int numero;
    private String nombre;

    public Grupo(int numero, String nombre) {
        this.numero = numero;
        this.nombre = nombre;
    }

    public void mostrarGrupo() {
        System.out.println("Grupo N°" + numero + " - " + nombre);
    }
}
