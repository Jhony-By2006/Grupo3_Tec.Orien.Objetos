/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package caseestudys11;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Usuario
 */
public class Estudiante {
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String nombres;
    private String dni;
    private Grupo grupo;
    private List<Matricula> matriculas;
    
    public Estudiante(String apellidoPaterno, String apellidoMaterno, String nombres, String dni, Grupo grupo) {
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.nombres = nombres;
        this.dni = dni;
        this.grupo = grupo;
        this.matriculas = new ArrayList<>();
    }

    public void agregarMatricula(Matricula matricula) {
        matriculas.add(matricula);
    }

    public void mostrarEstudiante() {
        System.out.println("Estudiante: " + nombres + " " + apellidoPaterno + " " + apellidoMaterno);
        System.out.println("DNI: " + dni);
        grupo.mostrarGrupo();
        System.out.println("Matrículas:");
        for (Matricula m : matriculas) {
            m.mostrarMatricula();
        }
    }
}
